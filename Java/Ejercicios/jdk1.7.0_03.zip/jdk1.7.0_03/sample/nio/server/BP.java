IPv6
----

 1. Main features
 2. Packet Format
 3. Addressing
 4. Transition mechanisms
 5. Changes in IPv6 protocol suite: ARP, FTP, ICMPv6, DHCP
----------------------------------------------------------------

1. Main features
	1 Larger address space
		The longer addresses 
			� simplify allocation of addresses, 
			� enable efficient route aggregation, 
			� and allow implementation of special addressing features.
		In IPv4, complex Classless Inter-Domain Routing (CIDR) methods were developed to make the best use of the small address space.
		Standard Subnets of 64 bits, automatically self-assigned addresses through ICMPv6 discovery.

	2 Multicasting
		Multicast provided.
		Broadcast-equivalent functionality by sending link-local all nodes multicast group at address ff02::1.
		Also, rendez-vous point addresses in an IPv6 multicast group address.
		NAT does not longer exist.
		Anycast also provided.

	3 Stateless address autoconfiguration (SLAAC)
		IPv6 hosts can configure themselves automatically when connected to a routed IPv6 network using Internet Control Message Protocol version 6 (ICMPv6) router discovery messages.

	4 Mandatory network-layer security
		IPsec was an integral part of the base IPv6 protocol suite.

	5 Simplified processing by routers
		In IPv6, the packet header and the process of packet forwarding have been simplified.
		� IPv6 header is simpler than IPv4,
		� IPv6 routers do not perform fragmentation.
		� IPv6 header is not protected by a checksum.
		� IPv6 TTL field as Hop Limit.

	6 Mobility
		Mobile IPv6 avoids triangular routing.

	7 Options extensibility
		Fixed header 40 bits.
		Optional header for quality of service, security, mobility, and others to be added without redesign of the basic protocol.

	8 Jumbograms
		High-MTU links: up to 2^32 - 1 bytes.

	9 Privacy
		Ephemeral IP addresses.

2. Packet Format
											0							 	1 								2 								3
								-----------------------------   ------------------------------  ------------------------------  ------------------------------
	Byte-Offset	| Bit Offset	0 	1 	2 	3 	4 	5 	6 	7 	8 	9 	10 	11 	12 	13 	14 	15 	16 	17 	18 	19 	20 	21 	22 	23 	24 	25 	26 	27 	28 	29 	30 	31
		 0 		|	  0 		| Version(4 b)|		Traffic Class (8 b)		  | 					Flow label (20 b)										  |
		 4 		|	 32 		| 				Payload length (16 b)						   | 		Next header (8 b) 	   | 	Hop Limit (8 b)			  |
		 8 		|	 64 		|																															  |
		12 		|	 96			|											Source address (128 b = 32 B)													  |
		16 		|	128			|																															  |
		20 		|	160			|_____________________________________________________________________________________________________________________________|
		24 		|	192 		|																															  |
		28 		|	224			|											Destination address (128 b = 32 B)												  |
		32 		|	256			|																															  |
		40 		|	288			